package com.tweetapp.model;

import lombok.Data;

@Data
public class Comments {

    String userId;
    String comment;
}
