export interface AuthenticationRequest{
    loginId: string;
    password: string;
}