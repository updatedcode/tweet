import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mytweet',
  templateUrl: './mytweet.component.html',
  styleUrls: ['./mytweet.component.css']
})
export class MytweetComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
